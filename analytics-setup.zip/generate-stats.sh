#!/bin/bash
# ============================================================
# Studio Visus — GoAccess Stats generieren
# ============================================================
# Konvertiert Caddy-JSON-Logs ins Combined-Format und
# erzeugt ein HTML-Dashboard unter /var/www/studiovisus/analytics/
#
# Aufruf:
#   sudo bash generate-stats.sh
#
# Automatisierung (z.B. taeglich um 3 Uhr):
#   sudo crontab -e
#   0 3 * * * /var/www/studiovisus/generate-stats.sh
# ============================================================

set -e

LOG="/var/log/caddy/studiovisus.log"
OUT="/var/www/studiovisus/analytics/index.html"
TMP="/tmp/studiovisus-clf.log"

# Pruefen ob Abhaengigkeiten da sind
for cmd in jq goaccess; do
  if ! command -v "$cmd" &>/dev/null; then
    echo "FEHLER: '$cmd' nicht installiert. Bitte: sudo apt install $cmd"
    exit 1
  fi
done

if [ ! -f "$LOG" ]; then
  echo "FEHLER: Logdatei $LOG nicht gefunden."
  echo "Ist das JSON-Logging im Caddyfile aktiviert?"
  exit 1
fi

echo "Konvertiere Caddy-JSON nach Combined Log Format..."

# Caddy JSON -> Combined Log Format (Apache/Nginx-kompatibel)
# Felder: IP - - [Datum] "METHOD URI PROTO" STATUS SIZE "REFERER" "UA"
jq -r '
  def pad(n): tostring | if length < n then (n - length) * "0" + . else . end;
  def months: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

  # Timestamp konvertieren (Unix -> CLF-Datum)
  (.ts | floor) as $epoch |
  ($epoch | strftime("%d")) as $day |
  ($epoch | strftime("%m") | tonumber - 1) as $mon |
  ($epoch | strftime("%Y")) as $year |
  ($epoch | strftime("%H:%M:%S")) as $time |
  ($epoch | strftime("%z")) as $tz |
  ("[" + $day + "/" + months[$mon] + "/" + $year + ":" + $time + " +0000]") as $date |

  # Felder extrahieren
  (.request.client_ip // .request.remote_ip // "-") as $ip |
  (.request.method // "GET") as $method |
  (.request.uri // "/") as $uri |
  (.request.proto // "HTTP/1.1") as $proto |
  (.status // 0 | tostring) as $status |
  (.size // 0 | tostring) as $size |
  (.request.headers["Referer"][0] // "-") as $ref |
  (.request.headers["User-Agent"][0] // "-") as $ua |

  # Combined Log Format ausgeben
  $ip + " - - " + $date + " \"" + $method + " " + $uri + " " + $proto + "\" " + $status + " " + $size + " \"" + $ref + "\" \"" + $ua + "\""
' "$LOG" > "$TMP" 2>/dev/null

LINES=$(wc -l < "$TMP")
echo "$LINES Logzeilen konvertiert."

if [ "$LINES" -eq 0 ]; then
  echo "Keine Logzeilen gefunden. Warte auf Traffic."
  rm -f "$TMP"
  exit 0
fi

# Ausgabe-Ordner sicherstellen
mkdir -p "$(dirname "$OUT")"

echo "Erzeuge GoAccess-Dashboard..."

goaccess "$TMP" \
  --log-format=COMBINED \
  --ignore-crawlers \
  --anonymize-ip \
  --no-query-string \
  -o "$OUT"

# Aufraeumen
rm -f "$TMP"

# Berechtigungen
chown caddy:caddy "$OUT" 2>/dev/null || true

echo ""
echo "Fertig: $OUT"
echo "Erreichbar unter: https://www.studiovisus.de/analytics/"
echo "(geschuetzt mit Basic-Auth, siehe Caddyfile)"
