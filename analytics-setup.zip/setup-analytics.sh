#!/bin/bash
# ============================================================
# Studio Visus — Analytics Setup (einmalig ausfuehren)
# ============================================================
# Installiert jq (falls noetig), richtet Basic-Auth ein,
# aktualisiert den Caddyfile und generiert den ersten Report.
#
# Aufruf:
#   sudo bash setup-analytics.sh
# ============================================================

set -e

echo ""
echo "=== Studio Visus Analytics Setup ==="
echo ""

# 1. jq installieren falls noetig
if ! command -v jq &>/dev/null; then
  echo "Installiere jq..."
  apt-get update -qq && apt-get install -y -qq jq
fi
echo "✓ jq installiert"

# 2. GoAccess pruefen
if ! command -v goaccess &>/dev/null; then
  echo "FEHLER: GoAccess nicht installiert."
  echo "Bitte: sudo apt install goaccess"
  exit 1
fi
echo "✓ GoAccess installiert"

# 3. Passwort fuer Basic-Auth setzen
echo ""
echo "Lege ein Passwort fuer den Analytics-Bereich fest."
echo "Benutzername wird: jan"
echo ""

# Passwort eingeben
read -s -p "Passwort: " PASS
echo ""
read -s -p "Passwort bestätigen: " PASS2
echo ""

if [ "$PASS" != "$PASS2" ]; then
  echo "FEHLER: Passwoerter stimmen nicht ueberein."
  exit 1
fi

# bcrypt-Hash erzeugen (Caddy kann das selbst)
echo "Erzeuge bcrypt-Hash..."
HASH=$(caddy hash-password --plaintext "$PASS" 2>/dev/null)

if [ -z "$HASH" ]; then
  echo "FEHLER: caddy hash-password fehlgeschlagen."
  echo "Versuche manuell: caddy hash-password"
  exit 1
fi

echo "✓ Passwort-Hash erzeugt"

# 4. Caddyfile aktualisieren — Analytics-Block einfuegen
CADDYFILE="/etc/caddy/Caddyfile"

if grep -q "basicauth /analytics" "$CADDYFILE" 2>/dev/null; then
  echo "⚠ Analytics-Block existiert bereits im Caddyfile. Ueberspringe."
else
  echo "Fuege Analytics-Route in Caddyfile ein..."

  # Block vor "file_server" einfuegen (letzte Zeile vor dem abschliessenden })
  # Suche die Stelle "file_server" und fuege davor ein
  ANALYTICS_BLOCK=$(cat <<BLOCK

	# -------------------------------------------------------
	# Analytics-Dashboard (Basic-Auth-geschuetzt)
	# -------------------------------------------------------
	basicauth /analytics/* {
		jan $HASH
	}

BLOCK
)

  # Einfuegen vor der letzten "file_server"-Zeile
  if grep -q "file_server" "$CADDYFILE"; then
    sed -i "/^\tfile_server$/i\\
\\t# -------------------------------------------------------\\
\\t# Analytics-Dashboard (Basic-Auth-geschuetzt)\\
\\t# -------------------------------------------------------\\
\\tbasicauth /analytics/* {\\
\\t\\tjan ${HASH//\//\\/}\\
\\t}" "$CADDYFILE"
    echo "✓ Caddyfile aktualisiert"
  else
    echo "⚠ 'file_server' nicht im Caddyfile gefunden."
    echo "Bitte folgenden Block manuell vor 'file_server' einfuegen:"
    echo "$ANALYTICS_BLOCK"
  fi
fi

# 5. Analytics-Verzeichnis anlegen
mkdir -p /var/www/studiovisus/analytics
chown caddy:caddy /var/www/studiovisus/analytics

# 6. generate-stats.sh installieren
cp /var/www/studiovisus/generate-stats.sh /var/www/studiovisus/generate-stats.sh 2>/dev/null || true
chmod +x /var/www/studiovisus/generate-stats.sh
echo "✓ Stats-Script installiert"

# 7. Caddy neu laden
echo "Lade Caddy-Konfiguration neu..."
systemctl reload caddy 2>/dev/null || systemctl restart caddy
echo "✓ Caddy neugestartet"

# 8. Ersten Report generieren
echo ""
echo "Generiere ersten Analytics-Report..."
bash /var/www/studiovisus/generate-stats.sh

echo ""
echo "============================================"
echo "  Setup abgeschlossen!"
echo "============================================"
echo ""
echo "  Dashboard: https://www.studiovisus.de/analytics/"
echo "  Login:     jan / [dein Passwort]"
echo ""
echo "  Report aktualisieren:"
echo "    sudo bash /var/www/studiovisus/generate-stats.sh"
echo ""
echo "  Automatisch taeglich (Crontab):"
echo "    sudo crontab -e"
echo "    0 3 * * * /var/www/studiovisus/generate-stats.sh"
echo ""
